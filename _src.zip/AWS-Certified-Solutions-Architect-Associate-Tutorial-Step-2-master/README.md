## $5 Tech Unlocked 2021!
[Buy and download this product for only $5 on PacktPub.com](https://www.packtpub.com/)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# AWS-Certified-Solutions-Architect-Associate-Tutorial-Step-2
AWS Certified Solutions Architect Associate Tutorial Step 2
